/*
  The UCT IMS IPTV Application Server
  Copyright (C) 2008 - University of Cape Town
  Robert Marston <rmarston@crg.ee.uct.ac.za>
  David Waiting <david@crg.ee.uct.ac.za>

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

/*FIXME: Dave took these from the client probably don't need a few of them */
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <regex.h>
#include <sys/time.h>
#include <eXosip2/eXosip.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <pthread.h>
#include <sys/ioctl.h>
#include "hashtable.h"
#include "hashtable_itr.h"
#include <libxml/parser.h>
#include <libxml/tree.h>

#define PORT 8010

/* Set up functions and variables for the hash table: Can be removed to reduce runtime and code size costs 
*  See hashtable.h for more information */
struct key
{
    char *sip_uri;
};

struct value
{
    char *rtsp_uri;
};

DEFINE_HASHTABLE_INSERT(insert_some, struct key, struct value);
DEFINE_HASHTABLE_SEARCH(search_some, struct key, struct value);
DEFINE_HASHTABLE_REMOVE(remove_some, struct key, struct value);
DEFINE_HASHTABLE_ITERATOR_SEARCH(search_itr_some, struct key);

/* Function used for converting of key to hash value */
static unsigned int
hashfromkey(void *ky)
{
    int i;
    unsigned int hashValue = 0;
    struct key *k = (struct key *)ky;
    for(i = 0; i < strlen(k->sip_uri); i++) {
        hashValue+= k->sip_uri[i] - 0;
    }
    return hashValue;
}

/* Function used to compare if two keys are equal */
static int
equalkeys(void *k1, void *k2)
{
    struct key *key1 = (struct key *)k1;
    struct key *key2 = (struct key *)k2;
    return (0 == strcmp(key1->sip_uri,key2->sip_uri));
}

/*******************************************************************************************/

int runcond=1;

/* Function: Catches the ctrl + c quiet event */
void stophandler(int signum) {
    printf("Shutting down...\n");
    runcond=0;
}

/* Function: Stores the key-value pair read from a file in the hash table */
int hashKeyVal(xmlNode *a_node, struct hashtable *hashTable) {
    struct key *k;
    struct value *v;
    xmlNode *cur_node;

    for(cur_node = a_node; cur_node; cur_node = cur_node->next) {
        if(!xmlStrcmp(cur_node->name, (const xmlChar *)"key")) {
                k = (struct key *)malloc(sizeof(struct key));
                if (NULL == k) {
                    printf("ran out of memory allocating a key\n");
                    return 1;
                }
                k->sip_uri = xmlNodeGetContent(cur_node);
        }
        else if(!xmlStrcmp(cur_node->name, (const xmlChar *)"value")) {
                v = (struct value *)malloc(sizeof(struct value));
                v->rtsp_uri = xmlNodeGetContent(cur_node);
                /* Try insert key and value into table else return and error */
                if (!insert_some(hashTable,k,v)) {
                    printf("Error: Could not insert key-value pair into hash table\n");
                    return 1;
                }
        }
    }
}

/* Function: Uses libxml to read from a file and extract the key-value pairs that will be stored in the hash table */
int read_file_fill_table(struct hashtable *hashTable, char *filename) {
    FILE *kvfile;
    xmlDocPtr doc;
    xmlNodePtr cur_node;
    int kvCount;        /* Used to keep track of how many key-value pairs were found */

    printf("Populating table with key-value pairs...\n");

    doc = xmlParseFile(filename);

    if (doc == NULL ) {
        fprintf(stderr,"ERROR: XML key-value file not parsed successfully\n");
        return 1;
    }

    cur_node = xmlDocGetRootElement(doc);
    if (cur_node == NULL) {
        fprintf(stderr,"ERROR: key-value file is empty\n");
        xmlFreeDoc(doc);
        return 1;
    }

    if (xmlStrcmp(cur_node->name, (const xmlChar *) "key-value_pairs")) {
        fprintf(stderr,"ERROR: document of the wrong type, root node != key-value_pairs\n");
        xmlFreeDoc(doc);
        return ;
    }

    cur_node = cur_node->xmlChildrenNode;
    kvCount = 0;
    while(cur_node != NULL) {
        if ((!xmlStrcmp(cur_node->name, (const xmlChar *)"key-value_pair"))) {
            kvCount++;
            /*Find key and value and then add to hash table */
            hashKeyVal(cur_node->children,hashTable);
        }
        /* Assign current node pointer to pointer of next node */
        cur_node = cur_node->next;
    }
    printf("Number of key-value pairs found in file %s is %d\n",filename, kvCount);
    /*free the document */
    xmlFreeDoc(doc);

    /*
     *Free the global variables that may
     *have been allocated by the parser.
     */
    xmlCleanupParser();

     /*k = (struct key *)malloc(sizeof(struct key));
                if (NULL == k) {
                    printf("ran out of memory allocating a key\n");
                    return 1;
                }
    k->sip_uri = temp;
    v = (struct value *)malloc(sizeof(struct value));
                        v->rtsp_uri = valString;
                        /* Try insert key and value into table else return and error 
                        if (!insert_some(hashTable,k,v)) {
                            printf("Error: Could not insert key-value pair into hash table\n");
                            return 1;
                        }


*/
    printf("Done.\n");
    return 0;
}


/*Function: Used to search the hashtable for a given key and extract the value if the key is found */
char* hash_lookupValue(struct hashtable *hashTable, char* sip_uri) {
    struct key *k;
    struct value *found;
    char *rtsp_uri;

    k = (struct key *)malloc(sizeof(struct key));
    if (NULL == k) {
        printf("ran out of memory allocating a key\n");
        return "serv_err";
    }

    k->sip_uri = sip_uri;
    if (NULL == (found = search_some(hashTable,k))) {
        printf("Error: key not found\n");
        return "key_err";
    }

    rtsp_uri = found->rtsp_uri;
    free(k);
    return rtsp_uri;
}

/*Function: Main eXosip function to get an event and take action on it*/
int get_exosip_events(struct hashtable *hashTable) {
    eXosip_event_t *je;

    if((je = eXosip_event_wait (0, 50)) != NULL) {
        fprintf(stderr, "Event type: %d %s\n", je->type, je->textinfo);

        eXosip_lock ();
        eXosip_automatic_action();
        eXosip_unlock ();

        /*If we recieved an invite from the client*/
        if (je->type == EXOSIP_CALL_INVITE) {
            char *requested_content, *rtsp_redirect_uri;
            osip_message_t *answer;

            /* The unique identifer for the content is placed into the address of the invite so we extract it here */
            requested_content = (((je->request)->to)->url)->username;
            printf("Client requesting: %s\n", requested_content);
            /* Here we use the identifer as the key and look up the approriate rstp address in the hash table */
            rtsp_redirect_uri = hash_lookupValue(hashTable, (char *)requested_content);

            /* Check that all went ok in finding the value for the given key */
            eXosip_lock ();
            if(!strcmp(rtsp_redirect_uri, "serv_err")) {
                /* If there was a problem allocating memory then return message to client indicating server error */
                eXosip_call_build_answer(je->tid, 500, &answer);
                eXosip_call_send_answer(je->tid, 500, answer);
            }
            else if(!strcmp(rtsp_redirect_uri, "key_err")) {
                /* If we couldn't find the key in the hash table then return a message to the client indicating this*/
                eXosip_call_build_answer(je->tid, 400, &answer);
                eXosip_call_send_answer(je->tid, 400, answer);
            }
            else {
                /* Send 200 OK to client with rtsp address appended in  the content type header field */
                eXosip_call_build_answer(je->tid, 200, &answer);
                eXosip_unlock ();

                char content_type_header[500];
                sprintf(content_type_header, "message/external-body; access-type=\"URL\"; "
                "expiration=\"Sat, 01 January 2011 09:00:00 GMT\"; URL=\"%s\"", rtsp_redirect_uri);

                if(osip_message_set_content_type(answer, content_type_header) != 0)
                printf("Error setting content type\n");

                eXosip_lock();
                eXosip_call_send_answer(je->tid, 200, answer);
            }
            eXosip_unlock ();
            eXosip_event_free(je);
        }
        if (je->type == EXOSIP_CALL_ACK ) {
            /* Terminate the call on receiving ack from client as no more interaction is needed */
            //eXosip_lock();
            //eXosip_call_terminate(je->cid, je->did);
            //eXosip_unlock();
        }
    }

    return 0;
}

int main(int argc, char *argv[])
{
    printf("UCT Media Control Function\n\nDave Waiting and Robert Marston (2008)\n");
    if(argc < 2) {
        printf("Usage: iptv_serv kvfile\n\t-kvfile: File containing the key-value pairs\n\n");
        return 0;
    }
    struct hashtable *hashTable;

    /* DEBUG VARIABLES
    struct key *kk;
    struct value *v;
    struct hashtable_itr *itr;
    int i;
    char *rtsp_uri; */

    eXosip_init();
    signal(SIGINT,stophandler);//hander to catch quit event

    /* Set up eXosip */
    if(eXosip_listen_addr(IPPROTO_UDP, NULL, PORT, AF_INET, 0) != 0) {
        printf("Error: Port busy - exiting\n");
        return -1;
    }
    else {
        printf("eXosip started and listening on port = %d\n", PORT);
    }
    printf("Creating Hashtable...\n");
    /* Create the hash table for storing content identifers and corresponding rtsp address */
    hashTable = create_hashtable(16, hashfromkey, equalkeys);
    /* Exit if hash table could not be created */
    if (NULL == hashTable) exit(-1);

    /* Read in the key-value pairs from file for hash table */
    if(!read_file_fill_table(hashTable, argv[1])) {
        /* //Debug: Iterate through table and print to screen
        itr = hashtable_iterator(hashTable);
        i = 0;
            if (hashtable_count(hashTable) > 0)
            {
                do {
                    kk = hashtable_iterator_key(itr);
                    v = hashtable_iterator_value(itr);
                    printf("Key = %s Value = %s\n", kk->sip_uri, v->rtsp_uri);
                    i++;

                } while (hashtable_iterator_advance(itr));
            }*/

        /* If success then start listening for client invites */
        printf("Server is ready to accept client requests... \n");
        while(runcond) {
            get_exosip_events(hashTable);
            usleep(2000);
        }
    }

    /* Destroy hashtable and free the key */
    printf("Destroying hashtable and freeing up memory...\n");
    hashtable_destroy(hashTable, 1);//free values when destroying hashtable
    printf("Complete... exiting.\n");
    return 0;

}
